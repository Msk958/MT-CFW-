# MT CFW Store - Digital Products Marketplace

A professional, full-stack digital products marketplace built with modern web technologies. Featuring a sleek "Neon Green on Black" aesthetic, comprehensive admin dashboard, and robust review system.

## 🚀 Features

- **Full Authentication System**: Integrated with Manus OAuth for secure user sessions.
- **Dynamic Product Catalog**: Browse products by categories with detailed product pages.
- **Advanced Review System**: 5-star rating system with verified purchase badges and user comments.
- **Shopping Cart & Checkout**: Seamless flow from adding items to placing orders.
- **Admin Dashboard**: Complete management of products, categories, and orders.
- **Responsive Design**: Optimized for both desktop and mobile devices.
- **Modern Tech Stack**: Built with React, TypeScript, Vite, Tailwind CSS, and Drizzle ORM.

## 🛠️ Tech Stack

- **Frontend**: React 19, Vite, Tailwind CSS, Lucide Icons, Radix UI.
- **Backend**: Express.js, tRPC for type-safe API communication.
- **Database**: MySQL with Drizzle ORM.
- **Testing**: Vitest for unit and integration tests.

## 📦 Installation & Setup

1. **Clone the repository**:
   ```bash
   git clone https://github.com/your-username/mt-cfwstore.git
   cd mt-cfwstore
   ```

2. **Install dependencies**:
   ```bash
   pnpm install
   ```

3. **Environment Variables**:
   Create a `.env` file in the root directory and add your database and OAuth credentials.

4. **Database Migration**:
   ```bash
   pnpm run db:push
   ```

5. **Start Development Server**:
   ```bash
   pnpm run dev
   ```

## 📜 Scripts

- `pnpm run dev`: Start development server.
- `pnpm run build`: Build for production.
- `pnpm run start`: Run production build.
- `pnpm run test`: Run tests.
- `pnpm run format`: Format code with Prettier.

## 📄 License

This project is licensed under the MIT License.

---

# متجر MT CFW - سوق المنتجات الرقمية

سوق متكامل للمنتجات الرقمية تم بناؤه باستخدام أحدث تقنيات الويب. يتميز بتصميم احترافي "أخضر نيون على أسود"، لوحة تحكم إدارية شاملة، ونظام تقييمات قوي.

## 🚀 المميزات

- **نظام مصادقة كامل**: متكامل مع Manus OAuth لجلسات مستخدم آمنة.
- **كتالوج منتجات ديناميكي**: تصفح المنتجات حسب الفئات مع صفحات تفصيلية لكل منتج.
- **نظام تقييمات متقدم**: نظام تقييم 5 نجوم مع شارات الشراء الموثقة وتعليقات المستخدمين.
- **سلة التسوق وإتمام الطلب**: تدفق سلس من إضافة العناصر إلى تقديم الطلبات.
- **لوحة تحكم الإدارة**: إدارة كاملة للمنتجات والفئات والطلبات.
- **تصميم متجاوب**: محسن لكل من أجهزة الكمبيوتر والهواتف المحمولة.
- **تقنيات حديثة**: مبني باستخدام React و TypeScript و Vite و Tailwind CSS و Drizzle ORM.

## 🛠️ التقنيات المستخدمة

- **الواجهة الأمامية**: React 19, Vite, Tailwind CSS, Lucide Icons, Radix UI.
- **الواجهة الخلفية**: Express.js, tRPC لاتصال API آمن النوع.
- **قاعدة البيانات**: MySQL مع Drizzle ORM.
- **الاختبارات**: Vitest لاختبارات الوحدة والتكامل.
